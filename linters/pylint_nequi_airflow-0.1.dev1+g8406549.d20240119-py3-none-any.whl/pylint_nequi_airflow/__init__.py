from pylint.lint import PyLinter

from pylint_nequi_airflow.dag import DAGChecker
from pylint_nequi_airflow.sensor import SensorChecker
from pylint_nequi_airflow.operator import OperatorChecker


def register(linter: PyLinter):
    """
    register checkers
    """
    linter.register_checker(DAGChecker(linter))
    linter.register_checker(SensorChecker(linter))
    linter.register_checker(OperatorChecker(linter))
