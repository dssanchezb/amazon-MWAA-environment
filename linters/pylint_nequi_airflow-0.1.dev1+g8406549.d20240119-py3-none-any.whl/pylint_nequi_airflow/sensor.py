"""
    This script implements a sensor Checker Class
    @author: Juan Esteban Agudelo Agudelo <juanesta@bancolombia.com.co>
"""
import logging
from typing import TYPE_CHECKING
import astroid
import re

from pylint.checkers import BaseChecker


# from __pkginfo__ import BASE_ID
BASE_ID = "86"

logging.basicConfig(level=logging.DEBUG)

if TYPE_CHECKING:
    from pylint.lint import PyLinter


class SensorChecker(BaseChecker):
    """
    Sensor Timeout Checker
    """

    name = "sensor"
    msgs = {
        f"E{BASE_ID}05": (
            "En el sensor, mode=poke solo puede usarse si el timeout es menor a 5 minutos",
            "sensor-attribute-mode-must-be-defined",
            """En el sensor, mode=poke solo puede usarse si el timeout es menor a 5 minutos""",
        ),
        f"E{BASE_ID}06": (
            "En todo sensor es obligatorio la definición del parametro timeout",
            "sensor-attribute-timeout-must-be-defined",
            "En todo sensor es obligatorio la definición del parametro timeout",
        ),
        f"E{BASE_ID}07": (
            "En el sensor, mode=poke solo puede usarse si el timeout es menor a 5 minutos",
            "sensor-invalid-mode-for-timeout",
            "En el sensor, mode=poke solo puede usarse si el timeout es menor a 5 minutos",
        ),
    }

    def visit_call(self, node: astroid.Call) -> None:
        """
        It applies linter rules to sensors
        """

        if hasattr(node.func, "inferred"):
            if hasattr(node.func.inferred()[0], "is_subtype_of"):
                if node.func.inferred()[0].is_subtype_of(
                    "airflow.sensors.base.BaseSensorOperator"
                ):
                    timeout, mode, poke_interval = [0, None, 0]
                    for key in node.keywords:
                        if key.arg == "timeout" and hasattr(key, "inferred"):
                            timeout = key.value.inferred()[0].value
                        elif key.arg == "mode" and hasattr(key, "inferred"):
                            mode = key.value.inferred()[0].value
                        elif key.arg == "poke_interval" and hasattr(key, "inferred"):
                            poke_interval = key.value.inferred()[0].value

                    if timeout == 0:
                        self.add_message(
                            "sensor-attribute-timeout-must-be-defined", node=node
                        )

                    if not mode:
                        self.add_message(
                            "sensor-attribute-mode-must-be-defined", node=node
                        )

                    if timeout >= 300 and mode != "reschedule":
                        self.add_message("sensor-invalid-mode-for-timeout", node=node)
