"""
    This script implements a sensor Checker Class
    @author: Juan Esteban Agudelo Agudelo <juanesta@bancolombia.com.co>
"""
import logging
from typing import TYPE_CHECKING
import astroid

from pylint.checkers import BaseChecker

# from __pkginfo__ import BASE_ID

logging.basicConfig(level=logging.DEBUG)

if TYPE_CHECKING:
    from pylint.lint import PyLinter

BASE_ID = "86"


class OperatorChecker(BaseChecker):
    dag_id: str = ""

    name = "operator"

    msgs = {
        f"E{BASE_ID}08": (
            "Este sensor solo se puede llamar en los dags de ingesta",
            "sensor-no-ingesta",
            "Este sensor solo se puede llamar en los dags de ingesta",
        ),
    }

    def visit_call(self, node: astroid.Call) -> None:
        """
        It applies linter rules to sensors
        """

        if node.func.name == "DAG":
            for key in node.keywords:
                if key.arg == "dag_id" and hasattr(key, "inferred"):
                    self.dag_id = key.value.inferred()[0].value

        if hasattr(node.func, "inferred"):
            if hasattr(node.func.inferred()[0], "is_subtype_of"):
                if node.func.inferred()[0].is_subtype_of(
                    "airflow.providers.amazon.aws.transfers.dynamodb_to_s3.DynamoDBToS3Operator"
                ) and not (self.dag_id.__contains__("ingesta")):
                    self.add_message("sensor-no-ingesta", node=node)
