"""
    This script implements DAG Checker Class
    @author: Juan Esteban Agudelo Agudelo <juanesta@bancolombia.com.co>
"""
import astroid

from pylint.checkers import BaseChecker
from pylint import interfaces

from pylint_nequi_airflow.__pkginfo__ import BASE_ID


class DAGChecker(BaseChecker):
    """
    DAGs checker class
    """

    __implements__ = interfaces.IAstroidChecker

    name = "dag-name"
    msgs = {
        f"E{BASE_ID}01": (
            "El ID del DAG debe estar en mayúsculas.",
            "dag-id-must-be-uppercase",
            "El ID del DAG debe estar en mayúsculas.",
        ),
        f"E{BASE_ID}02": (
            "La longitud del ID dag debe ser de entre 8 y 20 caracteres",
            "dag-id-between-eight-and-twenty-characters",
            "La longitud del ID dag debe ser de entre 8 y 20 caracteres",
        ),
        f"E{BASE_ID}03": (
            """El ID del DAG no tiene frecuencia de ejecución. 
               Las frecuencias permitidas son: [DI, HA, ME, SE, BI, TR, SM, AN, ES, IR]""",
            """dag-id-without-operation-frecuency""",
            """El ID del DAG no tiene frecuencia de ejecución. 
               Las frecuencias permitidas son: [DI, HA, ME, SE, BI, TR, SM, AN, ES, IR]""",
        ),
        f"E{BASE_ID}04": (
            "El ID del DAG no tiene el consecutivo de 3 digitos",
            "dag-id-without-code",
            "El ID del DAG no tiene el consecutivo de 3 digitos",
        ),
    }

    def visit_call(self, node: astroid.Call) -> None:
        """
        It applies linter rules to dags
        """

        if node.func.name == "DAG":
            dag_id = None
            for key in node.keywords:
                if key.arg == "dag_id" and hasattr(key, "inferred"):
                    dag_id = key.value.inferred()[0].value
                    # key_node = key
            if dag_id:
                if len(dag_id) < 8 or len(dag_id) > 20:
                    self.add_message(
                        "dag-id-between-eight-and-twenty-characters", node=node
                    )
                else:
                    frecuency: str = dag_id[3:5]
                    consecutive: str = dag_id[5:8]

                    if frecuency.upper() not in [
                        "DI",
                        "HA",
                        "SE",
                        "ME",
                        "BI",
                        "TR",
                        "SM",
                        "AN",
                        "ES",
                        "IR",
                    ]:
                        self.add_message(
                            "dag-id-without-operation-frecuency", node=node
                        )

                    if not consecutive.isnumeric():
                        self.add_message(
                            "dag-id-without-code",
                            node=node,
                        )
