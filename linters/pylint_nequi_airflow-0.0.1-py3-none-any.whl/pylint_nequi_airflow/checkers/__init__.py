from pylint.lint import PyLinter

from pylint_nequi_airflow.checkers.dag import DAGChecker
from pylint_nequi_airflow.checkers.sensor import SensorChecker


def register_checkers(linter: PyLinter):
    """
    register checkers
    """
    linter.register_checker(DAGChecker(linter))
    linter.register_checker(SensorChecker(linter))
