import astroid

from pylint.checkers import BaseChecker
from pylint import interfaces

from pylint_nequi_airflow.__pkginfo__ import BASE_ID


class DAGChecker(BaseChecker):
    """
    DAGs checker class
    """

    __implements__ = interfaces.IAstroidChecker

    name = "dag-name"
    msgs = {
        f"E{BASE_ID}00": (
            "nombre del dag debe ser un valor constante no nula, no una funcion, asignacion o interpolacion.",
            "dag-name-must-be-constant",
            "nombre del dag debe ser un valor constante, no una funcion, asignacion o interpolacion.",
        ),
        f"E{BASE_ID}01": (
            "El DAG solo puede tener hasta 20 caracteres",
            "dag-name-large",
            "El DAG solo puede tener hasta 20 caracteres",
        ),
        f"E{BASE_ID}02": (
            "El DAG debe tener mínimo 8 caracteres",
            "dag-name-short",
            "El DAG debe tener mínimo 8 caracteres",
        ),
        f"E{BASE_ID}03": (
            "El nombre del DAG no incluye frecuencia de operacion",
            "dag-name-not-operation-frecuency",
            "El dag debe de incluir una frecuencia de ejecucion",
        ),
        f"E{BASE_ID}04": (
            "El nombre del DAG no incluye el código del servicio",
            "dag-name-not-service-code",
            "El dag debe de incluir un codigo de servicio",
        ),
        f"E{BASE_ID}05": (
            "El nombre del DAG no incluye el consecutivo",
            "dag-name-not-consecutive",
            "El nombre del DAG no incluye el consecutivo",
        ),
    }

    def visit_call(self, node: astroid.Call) -> None:
        """
        It applies linter rules to dags
        """

        if node.func.name == "DAG":
            dag_id = None
            for key in node.keywords:
                if key.arg == "dag_id" and hasattr(key, "inferred"):
                    dag_id = key.value.inferred()[0].value
                elif key.arg == "dag_id":
                    self.add_message("dag-name-must-be-constant", node=node)
            if dag_id:
                if len(dag_id) < 8:
                    self.add_message("dag-name-short", node=node)
                else:
                    if len(dag_id) > 20:
                        self.add_message("dag-name-large", node=node)

                    frecuency: str = dag_id[3:5]
                    consecutive: str = dag_id[5:8]

                    if frecuency.upper() not in [
                        "DI",
                        "HA",
                        "SE",
                        "ME",
                        "BI",
                        "TR",
                        "SM",
                        "AN",
                        "ES",
                        "IR",
                    ]:
                        self.add_message("dag-name-not-operation-frecuency", node=node)

                    # if not consecutive.isdigit():
                    #    self.add_message(
                    #        "dag-name-not-consecutive",
                    #        node=node,
                    #    )
