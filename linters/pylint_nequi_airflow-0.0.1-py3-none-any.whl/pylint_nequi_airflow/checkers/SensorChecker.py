import logging
from typing import TYPE_CHECKING
import astroid

from pylint.checkers.utils import safe_infer
from pylint.checkers import BaseChecker
from pylint.checkers import utils
from pylint import interfaces

from pylint_nequi_airflow.__pkginfo__ import BASE_ID

logging.basicConfig(level=logging.DEBUG)

if TYPE_CHECKING:
    from pylint.lint import PyLinter


class SensorChecker(BaseChecker):
    """
    Sensor Timeout Checker
    """

    __implements__ = interfaces.IAstroidChecker

    name = "sensor"
    msgs = {
        f"C{BASE_ID}10": (
            "El sensor tiene un timeout muy largo para usar poke",
            "sensor-timeout-too-long-to-poke",
            """El sensor tiene un timeout mayor a 5 minutos pero 
            no está configurado en modo reschedule""",
        ),
        f"C{BASE_ID}11": (
            "La variable del sensor no empieza por await_for",
            "invalid-sensor-name",
            "La variable del sensor debe creace empezando por await_for",
        ),
    }

    @utils.check_messages()
    def visit_module(self, node) -> None:
        if isinstance(node.value, astroid.Call):
            function_node = safe_infer(node.value.func)
            logging.debug(function_node)
            if (
                function_node is not None
                and not isinstance(function_node, astroid.bases.BoundMethod)
                and hasattr(function_node, "is_subtype_of")
                and (
                    function_node.is_subtype_of("airflow.sensors.BaseSensorOperator")
                    or function_node.is_subtype_of(
                        "airflow.sensors.base.BaseSensorOperator"
                    )
                )
            ):
                timeout = None
                mode = None
                poke_interval = None

                for keyword in node.value.keywords:
                    if keyword.arg == "timeout" and isinstance(
                        keyword.value, astroid.Const
                    ):
                        timeout = keyword.value.value
                    elif keyword.arg == "mode" and isinstance(
                        keyword.value, astroid.Const
                    ):
                        mode = keyword.value.value
                    elif keyword.arg == "poke_interval" and isinstance(
                        keyword.value, astroid.Const
                    ):
                        poke_interval = keyword.value.value
                logging.debug(poke_interval)
                logging.debug(mode)

                if poke_interval >= 300 and mode != "reschedule":
                    self.add_message(
                        "sensor-timeout-too-long-to-poke", node=function_node
                    )
